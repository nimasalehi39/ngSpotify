export class ClAlbum {
    propAlbumId:number
}

