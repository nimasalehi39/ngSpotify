import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-navbar',
  templateUrl: './c-navbar.component.html',
  styleUrls: ['./c-navbar.component.css']
})
export class CNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
