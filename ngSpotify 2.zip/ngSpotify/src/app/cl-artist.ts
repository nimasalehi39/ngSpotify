import { ClAlbum } from './cl-album'

export class ClArtist {
    propArtistId: number
    propArtistName:string
    propArtistGenres:any
    propArtistAlbums:ClAlbum[]
}

