import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-about',
  templateUrl: './c-about.component.html',
  styleUrls: ['./c-about.component.css']
})
export class CAboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
